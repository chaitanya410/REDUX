export const ADD = (item) => {
    return {
        type: "ADD_CART",
        payload: item
    }
}
//for adding items 
// remove iteams
export const DLT = (id) => {
    return {
        type: "RMV_CART",
        payload: id
    }
}


//for removing particular elements 
export const REMOVE = (iteam) => {
    return {
        type: "RMV_ONE",
        payload: iteam
    }
}